package com.example.jakmallproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String JSON_URL = "https://api.icndb.com/jokes/random/10-";
    ListView listView;
    private List<ListItem> listItemList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView=findViewById(R.id.listView);
        TextView addButton = findViewById(R.id.addButton);

        listItemList = new ArrayList<>();
        loadData(3);


        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadData(1);
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                openDialog();
            }
        });
    }

    public void loadData(final int x){
        StringRequest stringRequest = new
                StringRequest(Request.Method.GET, JSON_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject object = new JSONObject(response);
                            JSONArray jsonArray = object.getJSONArray("value");
                            TextView addButton = findViewById(R.id.addButton);
                            for (int i = 0; i < x; i++) {
                                JSONObject listObject = jsonArray.getJSONObject(i);
                                ListItem listItem = new ListItem(listObject.getString("id"),
                                        listObject.getString("joke"),
                                        listObject.getString("categories"));
                                listItemList.add(listItem);

                            }
                            ListViewAdapter adapter = new ListViewAdapter(listItemList, getApplicationContext());
                            listView.setAdapter(adapter);
                            if(listItemList.size()==5)
                            {
                                addButton.setVisibility(View.INVISIBLE);
                            }
                            else
                            {
                                addButton.setVisibility(View.VISIBLE);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                }
        );

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void openDialog(){
        Dialog dialog = new Dialog();
        dialog.show(getSupportFragmentManager(),"example dialog");
    }


}
