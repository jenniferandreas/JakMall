package com.example.jakmallproject;

import androidx.appcompat.app.AppCompatActivity;

public class RefreshActivity extends AppCompatActivity {
}
