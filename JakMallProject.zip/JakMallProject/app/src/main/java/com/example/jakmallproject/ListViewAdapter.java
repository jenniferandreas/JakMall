package com.example.jakmallproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;

import java.util.List;

public class ListViewAdapter extends ArrayAdapter<ListItem> {
    private List<ListItem> listItemList;

    private Context context;

    public ListViewAdapter(List<ListItem> listItemList, Context context) {
        super(context,R.layout.list_item,listItemList);
        this.listItemList = listItemList;
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);

        View listViewItem = inflater.inflate(R.layout.list_item,null,true);
        TextView textViewJoke = listViewItem.findViewById(R.id.textViewJoke);

        ListItem listItem = listItemList.get(position);

        textViewJoke.setText(listItem.getJoke());

        return listViewItem;
    }
    public int getCount() {
        if (listItemList != null) {
            return Math.min(listItemList.size(), 5);
        } else {
            return 0;
        }
    }
}
